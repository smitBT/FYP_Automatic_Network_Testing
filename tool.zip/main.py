import os

def main():
    print("\nWelcome user to the intergrated semi-automatic testing tool")
    print("\nplease indicate which of our testing suites you require today"+'\n'+'processing delay tests(1)\n'+'firewall tests(2)'+'\ntest C(3)')
    selection= int(input())
    if selection == 1:
        #print('please specify a path to a topology file described in python')
        #topo_path = str(input())
        #print(topo_path)
        os.system('sudo python3 testA.py')
        os.system('sudo python3 report.py')
    elif selection == 2:
       os.system('sudo python3 testB.py')   
    elif selection == 3:
       os.system('sudo python3 testc.py')
    else:
       print("invlaid input")
    

if __name__ == '__main__':
    main()
    