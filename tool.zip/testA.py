from asyncio import protocols
from json.tool import main
import sys

from mininet.net import Mininet, DefaultController
from mininet.cli import CLI
from mininet.log import lg, info
from mininet.node import Node, Controller, OVSSwitch,RemoteController
from mininet.util import waitListening
from mininet.topolib import TreeTopo
from mininet.topo import Topo
from mininet.link import TCLink


def runTestA(controller):
    #here we initialise mininet and tell it not to build itself yet 
    net = Mininet(build=False,switch=OVSSwitch)
    #add our topology components to the network 
    net.addController(controller=controller)
    h1 = net.addHost( 'h1' )
    h2 = net.addHost( 'h2' )

    s1 = net.addSwitch( 's1' )

    #here we simulate  a small delay to add realism to our performance metrixs 
    software_defined_delay = 0.5
    net.addLink(h1 , s1,delay= (str(software_defined_delay)+'ms'))
    net.addLink(h2 , s1,delay= (str(software_defined_delay)+'ms'))
    # build our topology 
    net.build()
    #start our switches and controllers 
    net.start()
    
    #here we run a test on the set of hosts that exist on this default topology 
    hosts = (h1, h2)
    pingData = net.pingFull(hosts)
    for host in range (0, len(hosts)):
        #we collect data about our topology 
        (packetsSent, packetsReceived, minRtt, avgRtt, maxRtt, dev) = pingData[host][2]
        print(hosts[host].name + " Packets sent: " + str(packetsSent))
        print(hosts[host].name + " AVG RTT: " + str(avgRtt))
    #calculate the delay caused by the controler 
    processing_delay = avgRtt -(software_defined_delay*2)
    print("average processing delay: "+ str(processing_delay))
    
    #stop tests 
    net.stop()



if __name__ == '__main__':
    #on this line we tell the tool to expect a remote controler
    controller = RemoteController( "Remote Controller", port=6653)
    #if the user supplied a remote controller we pass it and if they didnt supply a remote controler on the specified port we instead use the deafult controler 
    if(controller.isListening("127.0.0.1", 6653)):
        controller = RemoteController
    else:
        controller = DefaultController
    runTestA(controller) 
    #c1 = net.addController('c1',controller=RemoteController,ip="192.168.1.100",port=6653)
